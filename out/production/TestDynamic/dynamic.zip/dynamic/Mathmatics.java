package dynamic;

public class Mathmatics {
	private Mathmatics() {
		
	}
	
	public static int multiplyInt(int x, int y) {
		return x*y;
	}
	
	public static float multiplyFloat(float x, float y) {
		return x*y;
	}

	public static double multiplyDouble(double x, double y) {
		return x*y;
	}

	public static int addingInt(int x, int y) {
		return x+y;
	}
	
	public static float addingFloat(float x, float y) {
		return x+y;
	}

	public static double addingDouble(double x, double y) {
		return x+y;
	}

	public static int adding(int x, int y) {
		return x+y;
	}
	
}
